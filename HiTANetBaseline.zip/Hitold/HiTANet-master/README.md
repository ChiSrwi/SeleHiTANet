# HiTANet
This is
 the code of HiTANet.
 ## Requirements
 pytorch == 1.3.1\
 sklearn == 0.19.1
 ## Data
 The project contains a sample toy data named as hf_sample in data folder.
 ## Main Entrance
 train_eval.py\
 contains training and evaluation codes.
 
 